function appendToDisplay(value) {
    document.getElementById('display').value += value;
}

function clearDisplay() {
    document.getElementById('display').value = '';
    document.getElementById('result').innerText = '';
}

function calculateResult() {
    try {
        var result = eval(document.getElementById('display').value);
        document.getElementById('result').innerText = '= ' + result;
    } catch (error) {
        document.getElementById('result').innerText = 'Error';
    }
}
